#include "../headers/Item.h"
#include <iostream>
#include "../constants.h"

using namespace std;

Item::Item()
{
  name = "";
  levelItem = 0;
  for(int i = 0; i < STAT_SIZE; i++)
  {
    item_stat[i] = 0;
  }
}

void Item::adjustStats(int stat[STAT_SIZE]) 
{
  for (int i = 0; i < STAT_SIZE; i++) 
  {
    stat[i] = stat[i] + item_stat[i];
  }
}

void Item::displayStats() 
{
  cout << "ITEM STATS" << endl << endl;
  for (int i = 0; i < STAT_SIZE; i++) 
  {
    if (item_stat[i] != 0) 
    {
    switch(i) 
    {
      case HEALTH:
        cout << "Health: " << item_stat[HEALTH] << endl;
      case INTELLIGENCE:
        cout << "Intelligence: " << item_stat[INTELLIGENCE] << endl;
      case AGILITY:
        cout << "Agility: " << item_stat[AGILITY] << endl;
      case ATTACK_STRENGTH:
        cout << "Attack Strength: " << item_stat[ATTACK_STRENGTH] << endl;
      case LUCK:
        cout << "Luck: " << item_stat[LUCK] << endl;
    }
   }
  }
}