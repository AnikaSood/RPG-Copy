#include "../headers/Warrior.h"
#include <iostream>
#include "../constants.h"

using namespace std;

Warrior::Warrior()
        :Player()
{
  setAttackStrength(30);
  setAgility(0);
}


// void Warrior::specialPower()
// {
// }

// 10 levels everytime you level up HEALTH ATTACK AND BONUS STAT = +2 and a mob will randomly drop another stat point at random

// void Warrior::levelUp(int level)
// {
//   playerLevelUp();
//   setAttackStrength(stats[ATTACK_STRENGTH] + 3);
// }
