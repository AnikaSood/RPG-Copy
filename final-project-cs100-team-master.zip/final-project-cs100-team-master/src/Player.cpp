#include "../headers/Player.h"
#include "../headers/Armor.h"
#include "../headers/Weapon.h"
#include "../headers/Potion.h"
#include <iostream>
#include "../constants.h"

using namespace std;

Player::Player()
{
  stats[HEALTH] = 50;
  stats[ATTACK_STRENGTH] = 10;
  stats[INTELLIGENCE] = 10;
  stats[LUCK] = 1;
  stats[AGILITY] = 1;

  armor.setHealth(5);
  weapon.setAttack(5);
  potion1.setAgility(0);
  potion2.setLuck(0);
  potion1.setHealth(0);

}

void Player::setName(string nm) 
{
  name = nm;
}

void Player::setHealth(int health) 
{
  stats[HEALTH] = health;
}

void Player::setIntelligence(int intelligence)
{
  stats[INTELLIGENCE] = intelligence;
}

void Player::setAgility(int agility) 
{
  stats[AGILITY] = agility;
}

void Player::setAttackStrength(int attack_strength)
{
  stats[ATTACK_STRENGTH] = attack_strength;
}

void Player::setLuck(int luck)
{
  stats[LUCK] = luck;
}

void Player::playerLevelUp()
{
  setHealth(stats[HEALTH] + 2);
  setAttackStrength(stats[ATTACK_STRENGTH] + 2);
}

int Player::getArmorHealth() 
{
  return armor.getHealth();
}
int Player::getWeaponStrength() 
{
  return weapon.getAttack();
}