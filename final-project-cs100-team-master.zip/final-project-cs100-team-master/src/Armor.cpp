#include "../constants.h"
#include "../headers/Armor.h"
#include "../headers/Item.h"
#include <string>
using namespace std;

Armor::Armor()
{
  name = "";
  levelItem = 0;
  for(int i = 0; i < STAT_SIZE; i++) 
  {
    item_stat[i] = 0;
  }
}

Armor::Armor(string name) 
{
  this->name = name;
  levelItem = 0;
  for(int i = 0; i < STAT_SIZE; i++) 
  {
    item_stat[i] = 0;
  }
}

void Armor::setHealth(int h) 
{
  this->health = h;
  item_stat[HEALTH] = h;
}

int Armor::getHealth() 
{
  return this->health;
}