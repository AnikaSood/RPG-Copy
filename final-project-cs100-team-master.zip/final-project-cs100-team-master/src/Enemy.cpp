#include "../headers/Enemy.h"
#include "../constants.h"
#include <iostream>

using namespace std;

//enemy constructor 

Enemy::Enemy(string nm)
{
  this->name = nm;
  this->health = 20;
  this->attack = 5;
  
}

void Enemy::setStats(int health, int attack) 
{
  this->health = health;
  this->attack = attack;
}

int Enemy::getHealth() 
{
  return this->health;
}

int Enemy::getAttack() 
{
  return this->attack;
}

void Enemy::adjustHealth(int dmg)
{
  this->health -= dmg;
}