#include "../headers/Healer.h"
#include <iostream>
#include "../constants.h"

using namespace std;

Healer::Healer()
       :Player()
{
  setHealth(70);
  setAttackStrength(5);
}

// void Healer::specialPower()
// {
//   setHealth(stats[HEALTH] * 1.5);
// }

// 10 levels everytime you level up HEALTH ATTACK AND BONUS STAT = +2 and a mob will randomly drop another stat point at random

// void Healer::levelUp(int level)
// {
//   playerLevelUp();
//   setHealth(stats[HEALTH] + 3);
// }
    
