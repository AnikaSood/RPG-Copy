#include "../headers/Assassin.h"
#include <iostream>
#include "../constants.h"

using namespace std;

Assassin::Assassin():Player()
{
    setHealth(30);
    setAgility(3);
}

// 10 levels everytime you level up HEALTH ATTACK AND BONUS STAT = +2 and a mob will randomly drop another stat point at random

// void Assassin::levelUp(int level)
// {
//     playerLevelUp();
//     setAgility(stats[AGILITY] + 10);
// }