#include "../headers/Potion.h"

#include <iostream>

using namespace std;

Potion::Potion() : Item()
{
    name = "";
    health = 0;
    luck = 0;
    agility = 0;
    for(int i = 0; i < STAT_SIZE; i++)
    {
        item_stat[i] = 0;
    }
}

int Potion::getAgility(){return this->agility;}
int Potion::getHealth() {return this->health;}
int Potion::getLuck() {return this->luck;}

void Potion::setAgility(int ag) {this->agility = ag;}
void Potion::setHealth(int new_health) {this->health = new_health;}
void Potion::setLuck(int new_luck) {this->luck = new_luck;}