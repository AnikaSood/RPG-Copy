#include "../constants.h"
#include "../headers/Weapon.h"
#include <string>
using namespace std;

//sword, dagger, staff
Weapon::Weapon()
{
    name = "";
    this->attack = 5;
    levelItem = 0;
    for(int i = 0; i < STAT_SIZE; i++)
    {
        item_stat[i] = 0;
    }
}

Weapon::Weapon(string name) 
{
    this->name = name;
    this->attack = 5;
    levelItem = 0;
    for(int i = 0; i < STAT_SIZE; i++) 
    {
        item_stat[i] = 0;
    }
}

void Weapon::setAttack(int a) 
{
    this->attack = a;
    item_stat[ATTACK_STRENGTH] = a;
}

int Weapon::getAttack() 
{
    return this->attack;
}

string Weapon::getName() 
{
    return this->name;
}
