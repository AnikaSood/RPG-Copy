#include "../headers/Mage.h"
#include "../constants.h"
#include <iostream>

using namespace std;

Mage::Mage()
     :Player()
{
  setHealth(30);
  setIntelligence(30);
}

// void Mage::specialPower()
// {
// }

// 10 levels everytime you level up HEALTH ATTACK AND BONUS STAT = +2 and a mob will randomly drop another stat point at random

// void Mage::levelUp(int level)
// {
//   playerLevelUp();
//   setIntelligence(stats[INTELLIGENCE] + 5);
// }
