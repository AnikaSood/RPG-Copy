#include "../headers/Friend.h"
#include <iostream>
#include "../constants.h"

using namespace std;

//friend constructor 

Friend::Friend(string nm)
{
  this->name = nm; 
}