#ifndef __CONSTANTS_H__
#define __CONSTANTS_H__

const int STAT_SIZE = 5;
const int INVENTORY_SIZE = 5;//can be a mix of anything

const int HEALTH = 0;
const int INTELLIGENCE = 1;
const int AGILITY = 2;
const int ATTACK_STRENGTH = 3;
const int LUCK = 4;

//all access the equpped inventory
const int ARMOR = 0;
const int WEAPON = 1;
const int POTION1 = 2;
const int POTION2 = 3;
const int POTION3 = 4;

#endif
