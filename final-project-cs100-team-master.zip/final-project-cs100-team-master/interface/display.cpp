#include "../constants.h"

#include "../headers/Armor.h"
#include "../headers/Assassin.h"
#include "../headers/NPC.h"
#include "../headers/Enemy.h"
#include "../headers/Friend.h"
#include "../headers/Healer.h"
#include "../headers/Mage.h"
#include "../headers/Player.h"
#include "../headers/Potion.h"
#include "../headers/Warrior.h"
#include "../headers/Weapon.h"

/*
#include "../src/Weapon.cpp"
#include "../src/Armor.cpp"
#include "../src/Assassin.cpp"
#include "../src/Enemy.cpp"
#include "../src/Friend.cpp"
#include "../src/Healer.cpp"
#include "../src/Item.cpp"
#include "../src/Mage.cpp"
#include "../src/Player.cpp"
#include "../src/Potion.cpp"
#include "../src/Warrior.cpp"
*/

using namespace std;

void helpScreen()
{
  // defines the action buttons
  cout << "Read the instructions given by the prompts in the game. They tell you which buttons you need to press. Each one has a specific action you need to follow. Have Fun!!!" << endl << endl;
}

void displayMainMenu()
{
  cout << "Hello!" << endl;
  cout << "Welcome to Hyperion!" << endl;
}

void displayOptions()
{
  cout << "Type a # to select an option: " << endl;
  cout << "1: Start the game" << endl;
  cout << "2: Help Screen" << endl;

  int choice;
  cin >> choice;
  cout << endl;

  while (choice == 2)
  {
    helpScreen();
    displayMainMenu();
    displayOptions();

    cin >> choice;
  }
}

string getName()
{
  string name;

  cout << "Please enter your desired name: ";
  cin >> name;
  cout << endl;

  return name;
}

int selectClass()
{
  int choice;

  cout << "Please type a number (1-4) to select your desired class: " << endl;
  cout << "1: Warrior" << endl;
  cout << "A warrior has vastly increased strength. This class is much stronger than any others. A fighter unparralled by any other." << endl;
  cout << "2: Healer" << endl;
  cout << "A healer has a large reserve of health. This class is a tank and has a ton of excess life force. A fighter not easily taken down." << endl;
  cout << "3: Assassin" << endl;
  cout << "An assassin is a sneaky, agile fighter. This class is able to run around and dodge attacks all over the battlefield." << endl;
  cout << "4: Mage" << endl;
  cout << "A mage is incredibly smart. This class has a very very high level of intelligence. This class will outsmart all of its opponents." << endl;

  cin >> choice;

  return choice;
}

void dispStats(Player player)
{
  cout << "Your current stats are: " << endl << endl;
  cout << "\tHealth: " << player.stats[HEALTH] << endl;
  cout << "\tAttack: " << player.stats[ATTACK_STRENGTH] << endl;
  cout << "\tIntelligence: " << player.stats[INTELLIGENCE] << endl;
  cout << "\tLuck: " << player.stats[LUCK] << endl;
  cout << "\tAgility: " << player.stats[AGILITY] << endl;
}

void exitMsg()
{
  cout << "Thank you for playing Hyperion! See you next time.\n";
  exit(0);
}

void choiceCheck(char choice, Player player)
{
  if (choice == '0')
  {
    cout << "Are you sure you want to exit the game" << endl;
    cout << "Enter y for yes and n for no" << endl;
    cin >> choice;

    if (choice == 'y')
    {
      exitMsg();
    }
  }

  if (choice == '1')
  {
    dispStats(player);
  }
}

void errorMsg()
{
  cout << "Incorrect character entered." << endl;
  cout << "Read the directions and try again: " << endl;
}

void tutorial(Player player)
{
  char choice;

  cout << "----- Tutorial ------" << endl;
  cout << "At any point in the game you can:" << endl;
  cout << "Enter 'x' to exit tutorial mode" << endl;
  cout << "Enter '0' to exit the whole game" << endl;
  cout << "Enter '1' to display stats" << endl;
  cout << "Enter '2' to continue game" << endl;
  cout << endl << endl;

  cin >> choice;
  if (choice == 'x' || choice == 'X')
  {
    return; // leave tutorial
  }

  choiceCheck(choice, player);

  cout << "Now let's begin the game!!!" << endl;

  cout << "During a fight, you can attack or drink a potion. Your armor, agility, and luck will help protect you from enemy attacks! To win a fight, attack the enemy until they reach 0 health! If you reach 0 health, you lose the fight and will have to restart the game!" << endl;

  cout << "An enemy approaches you! Get ready to fight!" << endl;

  cout << endl << endl;

  cout << "The enemy looked away! Enter 'E' to attack." << endl;
  cout << endl;

  cin >> choice;

  cout << endl;

  if (choice == 'x' || choice == 'X')
  {
    return; // leave function if they entered x
  }

  choiceCheck(choice, player);

  while ((choice != 'e') && (choice != 'E'))
  {
    errorMsg();
    cin >> choice;
    cout << endl;
  }

  cout << endl;
  cout << "The enemy took " << player.stats[ATTACK_STRENGTH] << " damage! Nice job!" << endl;

  cout << "A cute cat runs by and you become momentarily distracted! The enemy takes their chance to attack!" << endl;
  cout << endl;

  cout << "Lucky for you, you're wearing armor! You only took 2 damage!" << endl;
  cout << endl;

  cout << "Press B to continue" << endl;
  cin >> choice;
  if (choice != 'B' && choice != 'b')
  {
    errorMsg();
    cin >> choice;
    cout << endl;
  }

  cout << "You found a Potion on the floor and your attack strength increased by 10! Click 'E' to finish off the enemy!" << endl;
  cout << endl;

  cin >> choice;
  cout << endl;

  if (choice == 'x' || choice == 'X')
  {
    return;
  }

  choiceCheck(choice, player);

  while (choice != 'e' && choice != 'E')
  {
    errorMsg();
    cin >> choice;
    cout << endl;
  }
  cout << "You have finished off the enemy! It looks like they dropped a piece of their armor. After picking it up, your armor increases by 2!" << endl;

  cout << "----- END OF TUTORIAL -----" << endl;

  cout << endl;

  cout << "Press B to continue" << endl;
  cin >> choice;
  if (choice != 'B' && choice != 'b')
  {
    errorMsg();
    cin >> choice;
    cout << endl;
  }

  cout << "After you win a battle you go up a level! Your stats will increase. Winning boss fights will increase your level by 2 instead of 1!";
  cout << endl;

  cout << "To complete the game defeat your enemies! Defeating the final boss will finish the game!" << endl;
  cout << endl;
  cout << "Have fun!" << endl;
  return;
}

Player worldOne()
{
  Player player1;
  char choice;

  cout << "Time to start the game" << endl; 

  cout << "Press B to continue" << endl;
  cin >> choice;
  if (choice != 'B' && choice != 'b')
  {
    errorMsg();
    cin >> choice;
    cout << endl;
  }

  cout << "------ GAME START ------" << endl << endl;
  cout << "You open your eyes. Your head hurts a little. You don't recognize anything around you. You're surround by trees." << endl;
  cout << endl;
  cout << "There's a bag by your side. You look inside and see a weapon and a piece of armor. You put the armor on." << endl;
  cout << endl;

  cout << "Press B to continue" << endl;
  cin >> choice;
  if (choice != 'B' && choice != 'b')
  {
    errorMsg();
    cin >> choice;
    cout << endl;
  }

  Armor enemy1_armor;
  enemy1_armor.setHealth(5);

  cout << "------------------------" << endl;

  Enemy enemy1("Goblin");
  enemy1.setStats(20, 5); // 20 health, 5 attack

  cout << endl;
  cout << "No time to think! A goblin appears from behind a nearby tree." << endl;

  cout << "Oh no! The goblin lunges at you with a club! The attack does " << enemy1.getAttack() << " damage to you!" << endl;
  player1.stats[HEALTH] -= enemy1.getAttack();

  cout << "That hurt! Your try to reason with the goblin but he isn't listening! You have no other choice but to fight! Looks like it is your turn to make a move." << endl << endl;

  cout << "Do you remember how to attack? Press 'y' for yes or 'n' for no." << endl << endl;

  player1.stats[HEALTH] += player1.armor.getHealth();
  player1.stats[ATTACK_STRENGTH] += player1.weapon.getAttack();

  cin >> choice; 
  cout << endl;
  choiceCheck(choice, player1);

  while (choice != 'y' && choice != 'Y' && choice != 'n' && choice != 'N')
  {
    errorMsg(); 
    cin >> choice;
    cout << endl;
  }

  if (choice == 'n' || choice == 'N')
  {
    cout << "To attack, press 'E'" << endl << endl;
  }

  int count_rounds = 1;

  while (enemy1.getHealth() > 0 && player1.stats[HEALTH] > 0)
  {
    cout << "Attack!" << endl;
    cin >> choice;
    cout << endl;
    choiceCheck(choice, player1);

    while (choice != 'E' && choice != 'e')
    {
      errorMsg();
      cin >> choice;
      cout << endl;
    }

    switch (count_rounds)
    {
    case 1: // round 1 --------------------------------
      enemy1.adjustHealth(player1.stats[ATTACK_STRENGTH]);
      cout << "You used your weapon to attack the goblin! You successfully did "
           << player1.stats[ATTACK_STRENGTH]
           << " damage to the crazy goblin! The goblin now has "
           << enemy1.getHealth() << " health left!" << endl
           << endl;

      if (enemy1.getHealth() > 0)
      {
        cout << "The goblin didn't like that! Brace yourself! The goblin uses "
                "its club to do "
             << enemy1.getAttack() << " damage to you!" << endl
             << endl;
        player1.stats[HEALTH] -= enemy1.getAttack();
        cout << "Fight back!" << endl
             << endl;
      }
      break;

    case 2: // round 2 -----------------------------------
      enemy1.adjustHealth(player1.stats[ATTACK_STRENGTH]);
      cout << "You used your weapon to attack the goblin! You successfully did "
           << player1.stats[ATTACK_STRENGTH]
           << " damage to the goblin! The goblin now has "
           << enemy1.getHealth() << " health left!" << endl
           << endl;

      if (enemy1.getHealth() > 0)
      {
        cout << "The goblin didn't like that! Get ready! The goblin uses its "
                "club to do "
             << enemy1.getAttack() << " damage to you!" << endl
             << endl;
        player1.stats[HEALTH] -= enemy1.getAttack();
        cout << "Fight back!" << endl
             << endl;
      }
      break;
    case 3: // round 3 -----------------------------------
      // as a warrior/mage/assassin the goblin should not live after this round
      enemy1.adjustHealth(player1.stats[ATTACK_STRENGTH]);
      cout << "You used your weapon to attack the goblin! You successfully did "
           << player1.stats[ATTACK_STRENGTH] << " damage to the goblin!"
           << endl
           << endl;
      break;
    default:
      break;
    }
    count_rounds++;
  }
  if (player1.stats[HEALTH] <= 0)
  {
    cout << "You were defeated by the goblin! You'll have to restart the game!"
         << endl
         << endl;
    exit(0);
  }
  if (enemy1.getHealth() <= 0)
  {
    cout << endl;
    cout << "The goblin didn't get back up! You did it! You successfully "
            "defeated your first enemy!"
         << endl;
    cout << endl;
    cout << "Previous armor: " << player1.armor.getHealth() << endl;
    cout << "Looks like the goblin dropped a piece of armor. You picked it up "
            "and it fuses with your own armor! Your armor gained "
         << enemy1_armor.getHealth() << " defense!" << endl
         << endl;
    Armor new_armor1;
    new_armor1.setHealth(player1.armor.getHealth() + enemy1_armor.getHealth());
    player1.armor = new_armor1;

    cout << endl;
    cout << "You armor now has " << player1.armor.getHealth() << " defense!" << endl;
    cout << endl;

    cout << "But the goblin did some damage to you, let's take a look at your "
            "stats."
         << endl;

    player1.stats[HEALTH] += 5;
    dispStats(player1);
    cout << endl;
  } // end of first battle

  cout << "----------------" << endl;
  cout << endl;
  cout << "You continue walking through the trees. Behind a tree you spot a glowing light. It's a shop!" << endl;
  cout << "Press B to continue" << endl;
  cin >> choice;
  if (choice != 'B' && choice != 'b')
  {
    errorMsg(); // have them enter the character again
    cin >> choice;
    cout << endl;
  }
  cout << endl;
  cout << "------ SERAPINE'S SHOP ------" << endl;
  cout << endl;

  cout << "You walk into the shop and are greeted by the lady at the counter." << endl;
  cout << "???: Hi! I am Serapine! I saw you defeat that scary looking goblin just now! They aren't very friendly are they?" << endl;

  cout << "Press B to continue" << endl;
  cin >> choice;
  cout << endl;

  if (choice != 'B' && choice != 'b')
  {
    errorMsg(); // have them enter the character again
    cin >> choice;
    cout << endl;
  }
  cout << endl;

  int menu_choice = -1;
  while (menu_choice != 9)
  {
    cout << endl;
    cout << "Serapine: What can I do for you?" << endl;
    cout << "Press a number to choose your response." << endl;
    cout << endl;
    cout << "6: Where am I?" << endl;
    cout << "7: Where should I go now?" << endl;
    cout << "8: Can I upgrade my items?" << endl;
    cout << "9: Exit Shop" << endl;
    cout << endl;
    cin >> menu_choice;
    switch (menu_choice)
    {
    case 6:
      cout << "Serapine: This is The Forest of Lost Dreams! We've been getting a lot of visitors lately... I'm not sure where they come from..." << endl;
      break;

    case 7:
      cout << "Serapine: I'm not sure... But I know a merchant who works in the Desert, his name is Silko. He has the map to our world! If you head West, you can find him there!" << endl;
      break;

    case 8:
      char item_choice;
      cout << "Serapine: I can upgrade an item for you! Do you want to upgrade your armor or weapon?" << endl;
      cout << "A: Armor" << endl;
      cout << "W: Weapon" << endl;
      cin >> item_choice;
      cout << endl
           << endl;
      while (item_choice != 'A' && item_choice != 'a' && item_choice != 'W' && item_choice != 'w')
      {
        errorMsg(); // have them enter the character again
        cout << endl
             << endl;
        cout << "A: Armor" << endl;
        cout << "W: Weapon" << endl;
        cin >> item_choice;
        cout << endl
             << endl;
      }
      if (item_choice == 'A' || item_choice == 'a')
      {
        cout << "Serapine: Good choice! I upgraded your armor by 5!" << endl
             << endl;
        player1.armor.setHealth(player1.armor.getHealth() + 5);
        Armor new_armorS;
        new_armorS.setHealth(player1.armor.getHealth() + 5);
        player1.armor = new_armorS;
        player1.stats[HEALTH] += 5;
      }
      if (item_choice == 'W' || item_choice == 'w')
      {
        cout << "Serapine: Good choice! I upgraded your weapon by 2!" << endl
             << endl;
        player1.weapon.setAttack(player1.weapon.getAttack() + 2);
        Weapon new_weaponS;
        new_weaponS.setAttack(player1.weapon.getAttack() + 2);
        player1.weapon = new_weaponS;
        player1.stats[ATTACK_STRENGTH] += 2;
      }
      break;

    case 9:
      cout << "Serapine: Thanks for stopping by! Good luck!" << endl;
      break;
    default:
      break;
    }
  }
  cout << "You walk away from the shop..." << endl;
  cout << endl;
  cout << "Let's take a look at your stats again..." << endl;
  dispStats(player1);
  cout << endl;

  // choose dark forest or open field
  cout << "You reach a fork in the path."
       << endl; // can add incentive to take dark forest LATER TODO
  cout << "The left path leads to a dark forest. The right path leads to an "
          "open field."
       << endl;
  cout << "Type 'D' for the dark forest or 'F' for the open field." << endl;

  cin >> choice;

  while (choice != 'D' && choice != 'd' && choice != 'F' && choice != 'f')
  {
    errorMsg(); // have them enter the character again
    cin >> choice;
  }

  if (choice == 'D' || choice == 'd')
  {
    cout << "You enter the scary looking forest..." << endl
         << endl;
    cout << "Look out! It seems like there is something big approaching you!" << endl
         << endl;
  }

  if (choice == 'F' || choice == 'f')
  {
    cout << "You enter the bright field." << endl
         << endl;
    cout << "Wait. Why is there a big monster running right at you? Prepare to fight!" << endl
         << endl;
  }

  // fight 1
  Weapon enemy2_weapon;
  enemy2_weapon.setAttack(2);
  Enemy enemy2("Troll");
  enemy2.setStats(25, 6); // 25 health, 6 attack

  cout << endl;
  count_rounds = 1;

  while (enemy2.getHealth() > 0 && player1.stats[HEALTH] > 0)
  {
    cout << "Attack!" << endl;
    cin >> choice;
    cout << endl;
    choiceCheck(choice, player1);

    switch (count_rounds)
    {
    case 1: // round 1 --------------------------------
      enemy2.adjustHealth(player1.stats[ATTACK_STRENGTH]);
      cout << "You used your weapon to attack the troll! You successfully did "
           << player1.stats[ATTACK_STRENGTH]
           << " damage to the humungous troll! The troll now has "
           << enemy2.getHealth() << " health left!" << endl
           << endl;

      if (enemy2.getHealth() > 0)
      {
        cout << "The troll seems outraged at your attack. It prepares to whack you with a big club and does "
             << enemy2.getAttack() << " damage to you!" << endl
             << endl;
        player1.stats[HEALTH] -= enemy2.getAttack();
        cout << "That hurt, Fight back!" << endl
             << endl;
      }
      break;

    case 2: // round 2 -----------------------------------
      enemy2.adjustHealth(player1.stats[ATTACK_STRENGTH]);
      cout << "You used your weapon to attack the troll! You successfully did "
           << player1.stats[ATTACK_STRENGTH]
           << " damage to the troll! The troll now has "
           << enemy2.getHealth() << " health left!" << endl
           << endl;

      if (enemy2.getHealth() > 0)
      {
        cout << "The troll seems very mad! Get ready! The troll uses its "
                "club to do "
             << enemy2.getAttack() << " damage to you!" << endl
             << endl;
        player1.stats[HEALTH] -= enemy2.getAttack();
        cout << "Oh no! Fight back!" << endl
             << endl;
      }
      break;
    case 3: // round 3 -----------------------------------
      // as a warrior/mage/assassin the troll should not live after this round
      enemy2.adjustHealth(player1.stats[ATTACK_STRENGTH]);
      cout << "You used your weapon to attack the troll! You successfully did "
           << player1.stats[ATTACK_STRENGTH] << " damage to the troll!"
           << endl
           << endl;
      break;
    default:
      break;
    }
    count_rounds++;
  }
  if (player1.stats[HEALTH] <= 0)
  {
    cout << "Unfortunately, you were defeated by the troll, good luck next time!"
         << endl
         << endl;
    exit(0);
  }

  if (enemy2.getHealth() <= 0)
  {
    cout << endl;
    cout << "The troll didn't get back up! You did it! You successfully defeated the troll!"
         << endl
         << endl;
    cout << "Previous weapon: " << player1.weapon.getAttack() << endl;
    cout << "Looks like the troll dropped a weapon. You picked it up "
            "and it fuses with your own weapon! Your weapon gained "
         << enemy2_weapon.getAttack() << " attack!" << endl
         << endl;
    Weapon new_weapon2;
    new_weapon2.setAttack(player1.weapon.getAttack() + enemy2_weapon.getAttack());
    player1.weapon = new_weapon2;

    cout << endl;
    cout << "Your weapon now has " << player1.weapon.getAttack() << " attack!" << endl;
    cout << endl;

    // TODO: FIND A WAY TO UPDATE THE PLAYERS ARMOR IN THEIR INVENTORY
    // PLAYERS NEW ARMOR = CURRENT ARMOR'S HEALTH + ENEMY'S ARMOR HEALTH

    cout << "But the nasty troll did some damage to you, let's take a look at your "
            "stats."
         << endl;
    player1.stats[ATTACK_STRENGTH] += 2;
    dispStats(player1);
    cout << endl;
  } // end of first battle

  cout << "Good job defeating the troll. You stop to take a quick break when all of a sudden a witch swoops out of no where!" << endl
       << endl;

  // fight 2
  Armor enemy3_armor;
  enemy3_armor.setHealth(5);
  Enemy enemy3("Witch");
  enemy3.setStats(30, 7); // 25 health, 7 attack

  cout << endl;
  count_rounds = 1;

  while (enemy3.getHealth() > 0 && player1.stats[HEALTH] > 0)
  {
    cout << "Attack!" << endl;
    cin >> choice;
    cout << endl;
    choiceCheck(choice, player1);

    switch (count_rounds)
    {
    case 1: // round 1 --------------------------------
      enemy3.adjustHealth(player1.stats[ATTACK_STRENGTH]);
      cout << "You used your weapon to attack the witch! You successfully did "
           << player1.stats[ATTACK_STRENGTH]
           << " damage to the crafty witch! The witch now has "
           << enemy3.getHealth() << " health left!" << endl
           << endl;

      if (enemy3.getHealth() > 0)
      {
        cout << "The witch cackles and looks at you. It prepares to attack with a magic spell and does "
             << enemy3.getAttack() << " damage to you!" << endl
             << endl;
        player1.stats[HEALTH] -= enemy3.getAttack();
        cout << "That hurt, Fight back!" << endl
             << endl;
      }
      break;

    case 2: // round 2 -----------------------------------
      enemy3.adjustHealth(player1.stats[ATTACK_STRENGTH]);
      cout << "You used your weapon to attack the witch! You successfully did "
           << player1.stats[ATTACK_STRENGTH]
           << " damage to the witch! The witch now has "
           << enemy3.getHealth() << " health left!" << endl
           << endl;

      if (enemy3.getHealth() > 0)
      {
        cout << "The witch seems to go crazy! Get ready! The witch prepares a magic spell to do "
             << enemy3.getAttack() << " damage to you!" << endl
             << endl;
        player1.stats[HEALTH] -= enemy3.getAttack();
        cout << "Oh no! Fight back!" << endl
             << endl;
      }
      break;
    case 3: // round 3 -----------------------------------
      // as a warrior/mage/assassin the troll should not live after this round
      enemy3.adjustHealth(player1.stats[ATTACK_STRENGTH]);
      cout << "You used your weapon to attack the witch! You successfully did "
           << player1.stats[ATTACK_STRENGTH] << " damage to the witch!"
           << endl
           << endl;
      break;
    default:
      break;
    }
    count_rounds++;
  }
  if (player1.stats[HEALTH] <= 0)
  {
    cout << "Unfortunately, you were defeated by the witch, good luck next time!"
         << endl
         << endl;
    exit(0);
  }

  if (enemy3.getHealth() <= 0)
  {
    cout << endl;
    cout << "The witch didn't get back up! You did it! Congratulations you have defeated the witch!"
         << endl
         << endl;
    cout << "Previous armor: " << player1.armor.getHealth() << endl;
    cout << "Looks like the witch dropped an armor. You picked it up "
            "and it fuses with your own armor! Your armor gained "
         << enemy3_armor.getHealth() << " health!" << endl
         << endl;
    Weapon new_armor3;
    new_armor3.setAttack(player1.weapon.getAttack() + enemy2_weapon.getAttack());
    player1.weapon = new_armor3;

    cout << endl;
    cout << "Your armor now has " << player1.armor.getHealth() << " health!" << endl;
    cout << endl;

    // TODO: FIND A WAY TO UPDATE THE PLAYERS ARMOR IN THEIR INVENTORY
    // PLAYERS NEW ARMOR = CURRENT ARMOR'S HEALTH + ENEMY'S ARMOR HEALTH

    cout << "But the witch did some damage to you, let's take a look at your "
            "stats."
         << endl;
    player1.stats[HEALTH] += 5;
    dispStats(player1);
    cout << endl;
  } // end of second battle

  // village safe area
  cout << "It seems like there are no more monsters in the area. You see a nice looking village in the distance and walk over to it." << endl;
  cout << "You are greeted by a few people who offer some assistance! They tell you that just beyond the village is a huge treant boss that needs to be defeated in order to move on the the next world. The village priest blesses you with 10 health and 1 attack to prepare for the upcoming fight with the boss." << endl
       << endl;

  player1.stats[HEALTH] += 10;
  player1.stats[ATTACK_STRENGTH] += 1;

  cout << "Take a moment to rest here, and check your stats or inventory if needed, type the letter 'B' when you are ready to head over to the boss!" << endl
       << endl;

  cin >> choice;

  while (choice != 'B' && choice != 'b')
  {
    errorMsg(); // have them enter the character again
    cin >> choice;
  }

  if (choice == 'B' || choice == 'b')
  {
    cout << "The villagers wish you a warm goodbye and send their blessings for the upcoming fight." << endl
         << endl;
  }

  // treant boss
  Armor enemy4_armor;
  enemy4_armor.setHealth(10);
  Weapon enemy4_weapon;
  enemy4_weapon.setAttack(5);
  Enemy enemy4("Treant");
  enemy4.setStats(80, 8); // 25 health, 7 attack

  cout << "You exit the village and bravely trek your way towards the boss. It looks humongous! It seems like there will be a tough and long fight ahead." << endl
       << endl;

  cout << endl;
  count_rounds = 1;

  while (enemy4.getHealth() > 0 && player1.stats[HEALTH] > 0)
  {
    cout << "Attack!" << endl;
    cin >> choice;
    cout << endl;
    choiceCheck(choice, player1);

    switch (count_rounds)
    {
    case 1: // round 1 --------------------------------
      enemy4.adjustHealth(player1.stats[ATTACK_STRENGTH]);
      cout << "You used your weapon to attack the treant! You successfully did "
           << player1.stats[ATTACK_STRENGTH]
           << " damage to the strong treant! The treant now has "
           << enemy4.getHealth() << " health left!" << endl
           << endl;

      if (enemy4.getHealth() > 0)
      {
        cout << "The treant groans and looks at you. It prepares to attack with one of its many branches and does "
             << enemy3.getAttack() << " damage to you!" << endl
             << endl;
        player1.stats[HEALTH] -= enemy4.getAttack();
        cout << "That hurt, Fight back!" << endl
             << endl;
      }
      break;

    case 2: // round 2 -----------------------------------
      enemy4.adjustHealth(player1.stats[ATTACK_STRENGTH]);
      cout << "You used your weapon to attack the treant! You successfully did "
           << player1.stats[ATTACK_STRENGTH]
           << " damage to the treant! The treant now has "
           << enemy4.getHealth() << " health left!" << endl
           << endl;

      if (enemy4.getHealth() > 0)
      {
        cout << "The treant seems to go crazy! Get ready! The treant prepares an attack to do "
             << enemy4.getAttack() << " damage to you!" << endl
             << endl;
        player1.stats[HEALTH] -= enemy4.getAttack();
        cout << "Oh no! Fight back!" << endl
             << endl;
      }
      break;
    case 3: // round 3 -----------------------------------
      enemy4.adjustHealth(player1.stats[ATTACK_STRENGTH]);
      cout << "You attack the treant again. You successfully did "
           << player1.stats[ATTACK_STRENGTH]
           << " damage to the treant! The treant now has "
           << enemy4.getHealth() << " health left!" << endl
           << endl;

      if (enemy4.getHealth() > 0)
      {
        cout << "The treant is acting quite angry! Get ready! The treant prepares an attack to do "
             << enemy4.getAttack() << " damage to you!" << endl
             << endl;
        player1.stats[HEALTH] -= enemy4.getAttack();
        cout << "Time to fight back!" << endl
             << endl;
      }
      break;
    case 4: // round 4 -----------------------------------
      enemy4.adjustHealth(player1.stats[ATTACK_STRENGTH]);
      cout << "You grow tired but once again you attack the treant! You successfully did "
           << player1.stats[ATTACK_STRENGTH]
           << " damage to the treant! The treant now has "
           << enemy4.getHealth() << " health left!" << endl
           << endl;

      if (enemy4.getHealth() > 0)
      {
        cout << "The treant enters a state of fury! The treant prepares an attack to do "
             << enemy4.getAttack() << " damage to you!" << endl
             << endl;
        player1.stats[HEALTH] -= enemy4.getAttack();
        cout << "Oh no! Fight back!" << endl
             << endl;
      }
      break;
    case 5: // round 5 -----------------------------------
      enemy4.adjustHealth(player1.stats[ATTACK_STRENGTH]);
      cout << "Once again you attack the treant with your weapon! You successfully did "
           << player1.stats[ATTACK_STRENGTH]
           << " damage to the treant! The treant now has "
           << enemy4.getHealth() << " health left!" << endl
           << endl;

      if (enemy4.getHealth() > 0)
      {
        cout << "Watch out! The treant prepares an attack to do "
             << enemy4.getAttack() << " damage to you!" << endl
             << endl;
        player1.stats[HEALTH] -= enemy4.getAttack();
        cout << "Oh no! Fight back!" << endl
             << endl;
      }
      break;
    case 6: // round 6 -----------------------------------
      enemy4.adjustHealth(player1.stats[ATTACK_STRENGTH]);
      cout << "Once again you attack the treant with your weapon! You successfully did "
           << player1.stats[ATTACK_STRENGTH]
           << " damage to the treant! The treant now has "
           << enemy4.getHealth() << " health left!" << endl
           << endl;

      if (enemy4.getHealth() > 0)
      {
        cout << "Watch out! The treant prepares an attack to do "
             << enemy4.getAttack() << " damage to you!" << endl
             << endl;
        player1.stats[HEALTH] -= enemy4.getAttack();
        cout << "Oh no! Fight back!" << endl
             << endl;
      }
      break;
    default:
      break;
    }
    count_rounds++;
  }
  if (player1.stats[HEALTH] <= 0)
  {
    cout << "Unfortunately, you were defeated by the treant, nice try!"
         << endl
         << endl;
    exit(0);
  }

  if (enemy3.getHealth() <= 0)
  {
    cout << endl;
    cout << "The treant seems to be defeated! You did it! Congratulations you have defeated the boss in this world!"
         << endl
         << endl;
    cout << "Previous armor: " << player1.armor.getHealth() << endl;
    cout << "Previous weapon: " << player1.weapon.getAttack() << endl;
    cout << "Looks like the treant dropped an armor piece and a weapon. You picked it up "
            "and it fuses with your own armor and weapon! Both of your armor and weapon gain "
         << enemy4_armor.getHealth() << " health and " << enemy4_weapon.getAttack() << " attack!" << endl
         << endl;
    Weapon new_armor4;
    new_armor4.setAttack(player1.weapon.getAttack() + enemy2_weapon.getAttack());
    player1.weapon = new_armor4;

    cout << endl;
    cout << "Your armor now has " << player1.armor.getHealth() << " health!" << endl;
    cout << endl;

    // TODO: FIND A WAY TO UPDATE THE PLAYERS ARMOR IN THEIR INVENTORY
    // PLAYERS NEW ARMOR = CURRENT ARMOR'S HEALTH + ENEMY'S ARMOR HEALTH

    cout << "But the treant did a fair amount of damage to you, let's take a look at your "
            "stats."
         << endl;
    player1.stats[HEALTH] += 30;
    player1.stats[ATTACK_STRENGTH] += 5;
    dispStats(player1);
    cout << endl;
  } // end of first boss battle

  // after defeating move foward . next world
  cout << "You see a cave that you were told will take you somewhere. You eagerly walk towards it to see where it will take you. Type 'B' when you are ready to explore the cave." << endl
       << endl;

  cin >> choice;
  if (choice != 'B' && choice != 'b')
  {
    errorMsg(); // have them enter the character again
    cin >> choice;
    cout << endl;
  }

  return player1; // returns the player with all of its updates stats
}

Player worldTwo(Player playerWorldOne)
{
  Player player1 = playerWorldOne;
  char choice;

  // moved to new world encounter npcs . upgrade either weapon/armor, tells you
  // about the world
  cout << "Momentarily the world went dark . . ." << endl;
  cout << "A light shines again and you are greeted with a vast amount of sand dunes." << endl;
  cout << "???: Hello, I am Silko!" << endl;
  cout << "Silko? That sounds strangely familiar to you. . . Oh! Serapine told you about him! Silko proceeds to introduce himself to you. Silko gives you a map that shows the way to a scary looking scorpion boss. He tell you to head to a village on the map and to be wary of monsters on the way. He also offers to upgrade your armor or weapon. Type 'B' to continue" << endl
       << endl;

  cin >> choice;
  if (choice != 'B' && choice != 'b')
  {
    errorMsg(); // have them enter the character again
    cin >> choice;
    cout << endl;
  }

  int menu_choice = -1;
  while (menu_choice != 7)
  {
    cout << endl;
    cout << "Silko: What can I do for you?" << endl;
    cout << "Press a number to choose your response." << endl;
    cout << endl;
    cout << "6: Upgrade armor or weapon" << endl;
    cout << "7: Continue" << endl;
    cout << endl;
    cin >> menu_choice;
    switch (menu_choice)
    {
    case 6:
      char item_choice;
      cout << "Silko: I can upgrade an item for you! Do you want to upgrade your armor or weapon?" << endl;
      cout << "A: Armor" << endl;
      cout << "W: Weapon" << endl;
      cin >> item_choice;
      cout << endl
           << endl;
      while (item_choice != 'A' && item_choice != 'a' && item_choice != 'W' && item_choice != 'w')
      {
        errorMsg(); // have them enter the character again
        cout << endl
             << endl;
        cout << "A: Armor" << endl;
        cout << "W: Weapon" << endl;
        cin >> item_choice;
        cout << endl
             << endl;
      }
      if (item_choice == 'A' || item_choice == 'a')
      {
        cout << "Silko: Good choice! I upgraded your armor by 5!" << endl
             << endl;
        player1.armor.setHealth(player1.armor.getHealth() + 5);
        Armor new_armorS;
        new_armorS.setHealth(player1.armor.getHealth() + 5);
        player1.armor = new_armorS;
        player1.stats[HEALTH] += 5;
      }
      if (item_choice == 'W' || item_choice == 'w')
      {
        cout << "Silko: Good choice! I upgraded your weapon by 2!" << endl
             << endl;
        player1.weapon.setAttack(player1.weapon.getAttack() + 2);
        Weapon new_weaponS;
        new_weaponS.setAttack(player1.weapon.getAttack() + 2);
        player1.weapon = new_weaponS;
        player1.stats[ATTACK_STRENGTH] += 2;
      }
      break;

    case 7:
      cout << "Silko: Farewell, may your travels be fruitful." << endl;
      break;
    default:
      break;
    }
  }

  // choose cactus field or oasis

  cout << "The map shows two different paths that you can take. Type 'C' for the prickly cactus fields and 'O' for the tempting oasis." << endl
       << endl;

  cin >> choice;

  while (choice != 'C' && choice != 'c' && choice != 'O' && choice != 'o')
  {
    errorMsg(); // have them enter the character again
    cin >> choice;
  }

  if (choice == 'C' || choice == 'c')
  {
    cout << "You enter the tough cactus fields..." << endl
         << endl;
    cout << "Look out! It seems like there is something fast approaching you!" << endl
         << endl;
  }

  if (choice == 'O' || choice == 'o')
  {
    cout << "You enter the refreshing oasis." << endl
         << endl;
    cout << "Wait. Why is there something running right at you? Prepare to fight!" << endl
         << endl;
  }

  // fight 1
  Armor enemy5_armor;
  enemy5_armor.setHealth(5);
  cout << "------------------------" << endl;
  Enemy enemy5("Hyena");
  enemy5.setStats(45, 5); // 20 health, 5 attack

  cout << endl;
  cout << "No time to think! A hyena appears from behind a nearby tree." << endl;

  cout << "Oh no! The hyena lunges at you! The attack does " << enemy5.getAttack() << " damage to you!" << endl;
  player1.stats[HEALTH] -= enemy5.getAttack();

  player1.stats[HEALTH] += player1.armor.getHealth();
  player1.stats[ATTACK_STRENGTH] += player1.weapon.getAttack();

  cout << endl;
  choiceCheck(choice, player1);

  int count_rounds = 1;

  while (enemy5.getHealth() > 0 && player1.stats[HEALTH] > 0)
  {
    cout << "Attack!" << endl;
    cin >> choice;
    cout << endl;
    choiceCheck(choice, player1);

    while (choice != 'E' && choice != 'e')
    {
      errorMsg();
      cin >> choice;
      cout << endl;
    }

    switch (count_rounds)
    {
    case 1: // round 1 --------------------------------
      enemy5.adjustHealth(player1.stats[ATTACK_STRENGTH]);
      cout << "You used your weapon to attack the hyena! You successfully did "
           << player1.stats[ATTACK_STRENGTH]
           << " damage to the crazy hyena! The hyena now has "
           << enemy5.getHealth() << " health left!" << endl
           << endl;

      if (enemy5.getHealth() > 0)
      {
        cout << "The hyena didn't like that! Brace yourself! The hyena uses "
                "its claws to do "
             << enemy5.getAttack() << " damage to you!" << endl
             << endl;
        player1.stats[HEALTH] -= enemy5.getAttack();
        cout << "Fight back!" << endl
             << endl;
      }
      break;

    case 2: // round 2 -----------------------------------
      enemy5.adjustHealth(player1.stats[ATTACK_STRENGTH]);
      cout << "You used your weapon to attack the hyena! You successfully did "
           << player1.stats[ATTACK_STRENGTH]
           << " damage to the hyena! The hyena now has "
           << enemy5.getHealth() << " health left!" << endl
           << endl;

      if (enemy5.getHealth() > 0)
      {
        cout << "The hyena didn't like that! Get ready! The hyena uses its "
                "club to do "
             << enemy5.getAttack() << " damage to you!" << endl
             << endl;
        player1.stats[HEALTH] -= enemy5.getAttack();
        cout << "Fight back!" << endl
             << endl;
      }
      break;
    case 3: // round 3 -----------------------------------
      // as a warrior/mage/assassin the hyena should not live after this round
      enemy5.adjustHealth(player1.stats[ATTACK_STRENGTH]);
      cout << "You used your weapon to attack the hyena! You successfully did "
           << player1.stats[ATTACK_STRENGTH] << " damage to the hyena!"
           << endl
           << endl;
      break;
    default:
      break;
    }
    count_rounds++;
  }
  if (player1.stats[HEALTH] <= 0)
  {
    cout << "You were defeated by the hyena! You'll have to restart the game!"
         << endl
         << endl;
    exit(0);
  }
  if (enemy5.getHealth() <= 0)
  {
    cout << endl;
    cout << "The hyena didn't get back up! You did it! You successfully "
            "defeated the hyena!"
         << endl;
    cout << endl;
    cout << "Previous armor: " << player1.armor.getHealth() << endl;
    cout << "Looks like the hyena dropped a piece of armor. You picked it up "
            "and it fuses with your own armor! Your armor gained "
         << enemy5_armor.getHealth() << " defense!" << endl
         << endl;
    Armor new_armor1;
    new_armor1.setHealth(player1.armor.getHealth() + enemy5_armor.getHealth());
    player1.armor = new_armor1;

    cout << endl;
    cout << "You armor now has " << player1.armor.getHealth() << " defense!" << endl;
    cout << endl;

    cout << "But the hyena did some damage to you, let's take a look at your "
            "stats."
         << endl;

    player1.stats[HEALTH] += 5;
    dispStats(player1);
    cout << endl;
  } // end of first battle (second world)

  // fight 2
  Weapon enemy6_weapon;
  enemy6_weapon.setAttack(2);
  Enemy enemy6("Hyena");
  enemy6.setStats(45, 5); // 25 health, 5 attack

  cout <<endl<< endl;
  count_rounds = 1;

  while (enemy6.getHealth() > 0 && player1.stats[HEALTH] > 0)
  {
    cout << "Attack!" << endl;
    cin >> choice;
    cout << endl;
    choiceCheck(choice, player1);

    switch (count_rounds)
    {
    case 1: // round 1 --------------------------------
      enemy6.adjustHealth(player1.stats[ATTACK_STRENGTH]);
      cout << "You used your weapon to attack the hyena! You successfully did "
           << player1.stats[ATTACK_STRENGTH]
           << " damage to the sneaky hyena! The hyena now has "
           << enemy6.getHealth() << " health left!" << endl
           << endl;

      if (enemy6.getHealth() > 0)
      {
        cout << "The hyena seems outraged at your attack. It prepares to swipe at you with its claws and does "
             << enemy6.getAttack() << " damage to you!" << endl
             << endl;
        player1.stats[HEALTH] -= enemy6.getAttack();
        cout << "That hurt, Fight back!" << endl
             << endl;
      }
      break;

    case 2: // round 2 -----------------------------------
      enemy6.adjustHealth(player1.stats[ATTACK_STRENGTH]);
      cout << "You used your weapon to attack the hyena! You successfully did "
           << player1.stats[ATTACK_STRENGTH]
           << " damage to the hyena! The hyena now has "
           << enemy6.getHealth() << " health left!" << endl
           << endl;

      if (enemy6.getHealth() > 0)
      {
        cout << "The hyena seems very mad! Get ready! The hyena uses its "
                "sharp teeth to do "
             << enemy6.getAttack() << " damage to you!" << endl
             << endl;
        player1.stats[HEALTH] -= enemy6.getAttack();
        cout << "Oh no! Fight back!" << endl
             << endl;
      }
      break;
    case 3: // round 3 -----------------------------------
      // as a warrior/mage/assassin the hyena should not live after this round
      enemy6.adjustHealth(player1.stats[ATTACK_STRENGTH]);
      cout << "You used your weapon to attack the hyena! You successfully did "
           << player1.stats[ATTACK_STRENGTH] << " damage to the hyena!"
           << endl
           << endl;
      break;
    default:
      break;
    }
    count_rounds++;
  }
  if (player1.stats[HEALTH] <= 0)
  {
    cout << "Unfortunately, you were defeated by the hyena, good luck next time!"
         << endl
         << endl;
    exit(0);
  }

  if (enemy6.getHealth() <= 0)
  {
    cout << endl;
    cout << "The hyena didn't get back up! You did it! You successfully defeated the hyena!"
         << endl
         << endl;
    cout << "Previous weapon: " << player1.weapon.getAttack() << endl;
    cout << "Looks like the hyena dropped a weapon. You picked it up "
            "and it fuses with your own weapon! Your weapon gained "
         << enemy6_weapon.getAttack() << " attack!" << endl
         << endl;
    Weapon new_weapon6;
    new_weapon6.setAttack(player1.weapon.getAttack() + enemy6_weapon.getAttack());
    player1.weapon = new_weapon6;

    cout << endl;
    cout << "Your weapon now has " << player1.weapon.getAttack() << " attack!" << endl;
    cout << endl;

    cout << "But the nasty hyena did some damage to you, let's take a look at your "
            "stats."
         << endl;
    player1.stats[ATTACK_STRENGTH] += 2;
    dispStats(player1);
    cout << endl;
  } // end of second battle (second world)

  cout << "Good job defeating the hyena. Unfortunately, it seems like there was another hyena traveling with the other two hyenas!" << endl
       << endl;

  // fight 3
  Weapon enemy7_weapon;
  enemy7_weapon.setAttack(2);
  Enemy enemy7("Hyena");
  enemy7.setStats(45, 5); // 25 health, 5 attack

  cout << endl;
  count_rounds = 1;

  while (enemy7.getHealth() > 0 && player1.stats[HEALTH] > 0)
  {
    cout << "Attack!" << endl;
    cin >> choice;
    cout << endl;
    choiceCheck(choice, player1);

    switch (count_rounds)
    {
    case 1: // round 1 --------------------------------
      enemy7.adjustHealth(player1.stats[ATTACK_STRENGTH]);
      cout << "You used your weapon to attack the hyena! You successfully did "
           << player1.stats[ATTACK_STRENGTH]
           << " damage to the sneaky hyena! The hyena now has "
           << enemy7.getHealth() << " health left!" << endl
           << endl;

      if (enemy7.getHealth() > 0)
      {
        cout << "The hyena seems outraged at your attack. It prepares to swipe at you with its claws and does "
             << enemy7.getAttack() << " damage to you!" << endl
             << endl;
        player1.stats[HEALTH] -= enemy7.getAttack();
        cout << "That hurt, Fight back!" << endl
             << endl;
      }
      break;

    case 2: // round 2 -----------------------------------
      enemy7.adjustHealth(player1.stats[ATTACK_STRENGTH]);
      cout << "You used your weapon to attack the hyena! You successfully did "
           << player1.stats[ATTACK_STRENGTH]
           << " damage to the hyena! The hyena now has "
           << enemy7.getHealth() << " health left!" << endl
           << endl;

      if (enemy7.getHealth() > 0)
      {
        cout << "The hyena seems very mad! Get ready! The hyena uses its "
                "sharp teeth to do "
             << enemy7.getAttack() << " damage to you!" << endl
             << endl;
        player1.stats[HEALTH] -= enemy7.getAttack();
        cout << "Oh no! Fight back!" << endl
             << endl;
      }
      break;
    case 3: // round 3 -----------------------------------
      // as a warrior/mage/assassin the hyena should not live after this round
      enemy7.adjustHealth(player1.stats[ATTACK_STRENGTH]);
      cout << "You used your weapon to attack the hyena! You successfully did "
           << player1.stats[ATTACK_STRENGTH] << " damage to the hyena!"
           << endl
           << endl;
      break;
    default:
      break;
    }
    count_rounds++;
  }
  if (player1.stats[HEALTH] <= 0)
  {
    cout << "Unfortunately, you were defeated by the hyena, good luck next time!"
         << endl
         << endl;
    exit(0);
  }

  if (enemy7.getHealth() <= 0)
  {
    cout << endl;
    cout << "The hyena didn't get back up! You did it! You successfully defeated the hyena!"
         << endl
         << endl;
    cout << "Previous weapon: " << player1.weapon.getAttack() << endl;
    cout << "Looks like the hyena dropped a weapon. You picked it up "
            "and it fuses with your own weapon! Your weapon gained "
         << enemy7_weapon.getAttack() << " attack!" << endl
         << endl;
    Weapon new_weapon7;
    new_weapon7.setAttack(player1.weapon.getAttack() + enemy6_weapon.getAttack());
    player1.weapon = new_weapon7;

    cout << endl;
    cout << "Your weapon now has " << player1.weapon.getAttack() << " attack!" << endl;
    cout << endl;

    cout << "But the nasty hyena did some damage to you, let's take a look at your "
            "stats."
         << endl;
    player1.stats[ATTACK_STRENGTH] += 2;
    dispStats(player1);
    cout << endl;
  } // end of third battle (second world)

  // rest point / recover
  cout << "Good job! It seems like you were finally able to wipe out all of the hyenas roaming around the area. You see a small village up ahead. There are some villagers wandering around and you tell them what you were doing. They offer some food to heal you up in order for you to fight the boss!" << endl;
  cout << "The villagers point out the general location of the boss. Check your stats really quick before you leave the village! Type 'B' when you are ready to continue your journey." << endl
       << endl;

  dispStats(player1);

  cin >> choice;
  cout << endl;

  if (choice != 'B' && choice != 'b')
  {
    errorMsg(); // have them enter the character again
    cin >> choice;
    cout << endl;
  }
  cout << endl;

  // fight before boss
  Armor enemy8_armor;
  enemy8_armor.setHealth(5);
  Enemy enemy8("Shroot the Giant Sand Worm");
  enemy8.setStats(55, 7); // 25 health, 7 attack

  cout << "As you start traveling towards where the boss is located, Shroot the Giant Sand Worm pops out! Attack!" << endl
       << endl;
  count_rounds = 1;

  while (enemy8.getHealth() > 0 && player1.stats[HEALTH] > 0)
  {
    cout << "Attack!" << endl;
    cin >> choice;
    cout << endl;
    choiceCheck(choice, player1);

    switch (count_rounds)
    {
    case 1: // round 1 --------------------------------
      enemy8.adjustHealth(player1.stats[ATTACK_STRENGTH]);
      cout << "You used your weapon to attack Shroot the Giant Sand Worm! You successfully did "
           << player1.stats[ATTACK_STRENGTH]
           << " damage to the slippery Shroot the Giant Sand Worm! Shroot the Giant Sand Worm now has "
           << enemy8.getHealth() << " health left!" << endl
           << endl;

      if (enemy8.getHealth() > 0)
      {
        cout << "Shroot the Giant Sand Worm cackles and looks at you. It prepares to attack and does "
             << enemy8.getAttack() << " damage to you!" << endl
             << endl;
        player1.stats[HEALTH] -= enemy8.getAttack();
        cout << "That hurt, Fight back!" << endl
             << endl;
      }
      break;

    case 2: // round 2 -----------------------------------
      enemy8.adjustHealth(player1.stats[ATTACK_STRENGTH]);
      cout << "You used your weapon to attack Shroot the Giant Sand Worm! You successfully did "
           << player1.stats[ATTACK_STRENGTH]
           << " damage to Shroot the Giant Sand Worm! Shroot the Giant Sand Worm now has "
           << enemy8.getHealth() << " health left!" << endl
           << endl;

      if (enemy8.getHealth() > 0)
      {
        cout << "Shroot the Giant Sand Worm seems to go crazy! Get ready! Shroot the Giant Sand Worm prepares something powerful to do "
             << enemy8.getAttack() << " damage to you!" << endl
             << endl;
        player1.stats[HEALTH] -= enemy8.getAttack();
        cout << "Oh no! Fight back!" << endl
             << endl;
      }
      break;
    case 3: // round 3 -----------------------------------
      enemy8.adjustHealth(player1.stats[ATTACK_STRENGTH]);
      cout << "You  attacked Shroot the Giant Sand Worm! You successfully did "
           << player1.stats[ATTACK_STRENGTH]
           << " damage to Shroot the Giant Sand Worm! Shroot the Giant Sand Worm now has "
           << enemy8.getHealth() << " health left!" << endl
           << endl;

      if (enemy8.getHealth() > 0)
      {
        cout << "Shroot the Giant Sand Worm looks very mad! Get ready! Shroot the Giant Sand Worm prepares something powerful to do "
             << enemy8.getAttack() << " damage to you!" << endl
             << endl;
        player1.stats[HEALTH] -= enemy8.getAttack();
        cout << "Oh no! Fight back!" << endl
             << endl;
      }
      break;
    case 4: // round 4 -----------------------------------
      enemy8.adjustHealth(player1.stats[ATTACK_STRENGTH]);
      cout << "Using your weapon you successfully did "
           << player1.stats[ATTACK_STRENGTH]
           << " damage to Shroot the Giant Sand Worm! Shroot the Giant Sand Worm now has "
           << enemy8.getHealth() << " health left!" << endl
           << endl;

      if (enemy8.getHealth() > 0)
      {
        cout << "Shroot the Giant Sand Worm seems to be weaker! It looks desperate and it does "
             << enemy8.getAttack() << " damage to you!" << endl
             << endl;
        player1.stats[HEALTH] -= enemy8.getAttack();
        cout << "Oh no! Fight back!" << endl
             << endl;
      }
      break;
    default:
      break;
    }
    count_rounds++;
  }
  if (player1.stats[HEALTH] <= 0)
  {
    cout << "Unfortunately, you were defeated by Shroot the Giant Sand Worm, good luck next time!"
         << endl
         << endl;
    exit(0);
  }

  if (enemy8.getHealth() <= 0)
  {
    cout << endl;
    cout << "Shroot the Giant Sand Worm didn't get back up! You did it! Congratulations you have defeated Shroot the Giant Sand Worm!"
         << endl
         << endl;
    cout << "Previous armor: " << player1.armor.getHealth() << endl;
    cout << "Looks like Shroot the Giant Sand Worm dropped armor. You picked it up "
            "and it fuses with your own armor! Your armor gained "
         << enemy8_armor.getHealth() << " health!" << endl
         << endl;
    Weapon new_armor8;
    new_armor8.setAttack(player1.weapon.getAttack() + enemy7_weapon.getAttack());
    player1.weapon = new_armor8;

    cout << endl;
    cout << "Your armor now has " << player1.armor.getHealth() << " health!" << endl;
    cout << endl;

    cout << "But Shroot the Giant Sand Worm did some damage to you, let's take a look at your "
            "stats."
         << endl;
    player1.stats[HEALTH] += 10;
    dispStats(player1);
    cout << endl;
  } // end of fourth battle (second world)

  // scorpion boss fight
  Armor enemy9_armor;
  enemy9_armor.setHealth(10);
  Weapon enemy9_weapon;
  enemy9_weapon.setAttack(5);
  Enemy enemy9("Scorpion");
  enemy9.setStats(100, 10); // 25 health, 7 attack

  cout << "After defeating Shroot the Giant Sand Worm, you see the lair of the boss!" << endl
       << endl;

  cout << endl;
  count_rounds = 1;

  while (enemy9.getHealth() > 0 && player1.stats[HEALTH] > 0)
  {
    cout << "Attack!" << endl;
    cin >> choice;
    cout << endl;
    choiceCheck(choice, player1);

    switch (count_rounds)
    {
    case 1: // round 1 --------------------------------
      enemy9.adjustHealth(player1.stats[ATTACK_STRENGTH]);
      cout << "You used your weapon to attack the scorpion! You successfully did "
           << player1.stats[ATTACK_STRENGTH]
           << " damage to the devious scorpion! The scorpion now has "
           << enemy9.getHealth() << " health left!" << endl
           << endl;

      if (enemy9.getHealth() > 0)
      {
        cout << "The scorpion chitters angrily and looks at you. It prepares to attack with one of its large pincers and does "
             << enemy9.getAttack() << " damage to you!" << endl
             << endl;
        player1.stats[HEALTH] -= enemy9.getAttack();
        cout << "That hurt, Fight back!" << endl
             << endl;
      }
      break;

    case 2: // round 2 -----------------------------------
      enemy9.adjustHealth(player1.stats[ATTACK_STRENGTH]);
      cout << "You used your weapon to attack the scorpion! You successfully did "
           << player1.stats[ATTACK_STRENGTH]
           << " damage to the scorpion! The scorpion now has "
           << enemy9.getHealth() << " health left!" << endl
           << endl;

      if (enemy9.getHealth() > 0)
      {
        cout << "The scorpion seems to go crazy! Get ready! The scorpion prepares an attack to do "
             << enemy9.getAttack() << " damage to you!" << endl
             << endl;
        player1.stats[HEALTH] -= enemy9.getAttack();
        cout << "Oh no! Fight back!" << endl
             << endl;
      }
      break;
    case 3: // round 3 -----------------------------------
      enemy9.adjustHealth(player1.stats[ATTACK_STRENGTH]);
      cout << "You attack the scorpion again. You successfully did "
           << player1.stats[ATTACK_STRENGTH]
           << " damage to the scorpion! The scorpion now has "
           << enemy9.getHealth() << " health left!" << endl
           << endl;

      if (enemy9.getHealth() > 0)
      {
        cout << "The scorpion is acting quite angry! Get ready! The scorpion prepares an attack to do "
             << enemy9.getAttack() << " damage to you!" << endl
             << endl;
        player1.stats[HEALTH] -= enemy9.getAttack();
        cout << "Time to fight back!" << endl
             << endl;
      }
      break;
    case 4: // round 4 -----------------------------------
      enemy9.adjustHealth(player1.stats[ATTACK_STRENGTH]);
      cout << "You grow tired but once again you attack the scorpion! You successfully did "
           << player1.stats[ATTACK_STRENGTH]
           << " damage to the scorpion! The scorpion now has "
           << enemy9.getHealth() << " health left!" << endl
           << endl;

      if (enemy9.getHealth() > 0)
      {
        cout << "The scorpion enters a state of fury! The scorpion prepares an attack to do "
             << enemy9.getAttack() << " damage to you!" << endl
             << endl;
        player1.stats[HEALTH] -= enemy9.getAttack();
        cout << "Oh no! Fight back!" << endl
             << endl;
      }
      break;
    case 5: // round 5 -----------------------------------
      enemy9.adjustHealth(player1.stats[ATTACK_STRENGTH]);
      cout << "Once again you attack the scorpion with your weapon! You successfully did "
           << player1.stats[ATTACK_STRENGTH]
           << " damage to the scorpion! The scorpion now has "
           << enemy9.getHealth() << " health left!" << endl
           << endl;

      if (enemy9.getHealth() > 0)
      {
        cout << "Watch out! The scorpion prepares an attack to do "
             << enemy9.getAttack() << " damage to you!" << endl
             << endl;
        player1.stats[HEALTH] -= enemy9.getAttack();
        cout << "Oh no! Fight back!" << endl
             << endl;
      }
      break;
    case 6: // round 6 -----------------------------------
      enemy9.adjustHealth(player1.stats[ATTACK_STRENGTH]);
      cout << "Once again you attack the scorpion with your weapon! You successfully did "
           << player1.stats[ATTACK_STRENGTH]
           << " damage to the scorpion! The scorpion now has "
           << enemy9.getHealth() << " health left!" << endl
           << endl;

      if (enemy9.getHealth() > 0)
      {
        cout << "Watch out! The scorpion prepares an attack to do "
             << enemy9.getAttack() << " damage to you!" << endl
             << endl;
        player1.stats[HEALTH] -= enemy9.getAttack();
        cout << "Oh no! Fight back!" << endl
             << endl;
      }
      break;
    case 7: // round 7 -----------------------------------
      enemy9.adjustHealth(player1.stats[ATTACK_STRENGTH]);
      cout << "Once again you attack the scorpion with your weapon! your attacks seem to be working! You successfully did "
           << player1.stats[ATTACK_STRENGTH]
           << " damage to the scorpion! The scorpion now has "
           << enemy9.getHealth() << " health left!" << endl
           << endl;

      if (enemy9.getHealth() > 0)
      {
        cout << "Watch out! The scorpion prepares an attack to do "
             << enemy9.getAttack() << " damage to you!" << endl
             << endl;
        player1.stats[HEALTH] -= enemy9.getAttack();
        cout << "Oh no! Fight back!" << endl
             << endl;
      }
      break;
    case 8: // round 8 -----------------------------------
      enemy9.adjustHealth(player1.stats[ATTACK_STRENGTH]);
      cout << "The scorpion seems to be on its last legs! You successfully did "
           << player1.stats[ATTACK_STRENGTH]
           << " damage to the scorpion! The scorpion now has "
           << enemy9.getHealth() << " health left!" << endl
           << endl;

      if (enemy9.getHealth() > 0)
      {
        cout << "Watch out! The scorpion prepares an attack to do "
             << enemy9.getAttack() << " damage to you!" << endl
             << endl;
        player1.stats[HEALTH] -= enemy9.getAttack();
        cout << "Oh no! Fight back!" << endl
             << endl;
      }
      break;
    default:
      break;
    }
    count_rounds++;
  }

  cout << "Press B to continue" << endl;
  cin >> choice;
  if (choice != 'B' && choice != 'b')
  {
    errorMsg(); // have them enter the character again
    cin >> choice;
    cout << endl;
  }

  if (player1.stats[HEALTH] <= 0)
  {
    cout << "Unfortunately, you were defeated by the scorpion, nice try!"
         << endl
         << endl;
    exit(0);
  }

  if (enemy9.getHealth() <= 0)
  {
    cout << endl;
    cout << "The scorpion seems to be defeated! You did it! Congratulations you have defeated the boss in this world!"
         << endl
         << endl;
    cout << "Previous armor: " << player1.armor.getHealth() << endl;
    cout << "Previous weapon: " << player1.weapon.getAttack() << endl;
    cout << "Looks like the scorpion dropped an armor piece and a weapon. You picked it up "
            "and it fuses with your own armor and weapon! Both of your armor and weapon gain "
         << enemy9_armor.getHealth() << " health and " << enemy9_weapon.getAttack() << " attack!" << endl
         << endl;
    Weapon new_armor4;
    new_armor4.setAttack(player1.weapon.getAttack() + enemy9_weapon.getAttack());
    player1.weapon = new_armor4;

    cout << endl;
    cout << "Your armor now has " << player1.armor.getHealth() << " health!" << endl;
    cout << endl;

    cout << "But the scorpion did a fair amount of damage to you, let's take a look at your "
            "stats."
         << endl;
    player1.stats[HEALTH] += 30;
    player1.stats[ATTACK_STRENGTH] += 5;
    dispStats(player1);
    cout << endl;
  } // end of second boss battle

  // see cave takes you to world 3 (beach)
  // NOW END -------------------------------------------------------------

  cout << "Congratulations on defeating all the monsters! You have saved everyone that lives here and can now go home! Press 'B' when you would like to return home (ends the game)." << endl
       << endl;

  cin >> choice;
  if (choice != 'B' && choice != 'b')
  {
    errorMsg(); // have them enter the character again
    cin >> choice;
    cout << endl;
  }
  else
  {
    exit(0);
  }

  return player1;
}

// will be scrapped due to time constraints and insufficient manpower
void worldThree()
{
  // fight 1 . 2 sirens attacking (the turtles are watching you)

  // enter underwater kingdom - Queen/King tell you everything upgrade either
  // armor/weapon

  // choose either seaweed forest or coral reef or underground cavern

  // fight 1

  // fight 2 (the turtles are watching you)

  // fight 3

  // fight 4

  // rest area . heal then get attacked (the turtles are still watching you)

  // crab boss fight

  // portal to go home!! step through portal
}

// UNEEDED PUT IN END OF WORLD TWO
void endScreen()
{ // end screen -- when you click 'enter' will take you back to
  // main menu
  // endscreen congratulates you for finishing

  // type in something to take you back to the main menu . basically restarts
  // the game
}

Player createCharacter(int choice)
{
  /** CHARACTER SELECTION **/
  Player player;
  switch (choice)
  {
  case 1:
    // Warrior choice
    player = Warrior();
    // ERROR BRO DONT DELETE THIS COUT LINE
    cout << "-";
    break;

  case 2:
    // Healer
    player = Healer();
    cout << "-";
    break;

  case 3:
    // Assassin
    player = Assassin();
    cout << "-";
    break;

  case 4:
    // Mage
    player = Mage();
    cout << "-";
    break;

  default:
    break;
  }
  return player;
}

int main()
{
  displayMainMenu(); // will display the LOADING SCREEN
  displayOptions();  // can type (1) to Start or (2) for help

  string nameChoice = getName();

  // store character choice in choice
  int choice = selectClass();

  Player player = createCharacter(choice);

  player.setName(nameChoice);

  tutorial(player);

  player = worldOne();
  Player playerWorldOne = player;

  // playerWorldOne = player;

  Player playerWorldTwo = worldTwo(playerWorldOne);

  // delete player;
  return 0;
}
