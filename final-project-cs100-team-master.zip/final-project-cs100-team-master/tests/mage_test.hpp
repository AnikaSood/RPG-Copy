#ifndef __MAGE_TEST_HPP__
#define __MAGE_TEST_HPP__

#include "gtest/gtest.h"
#include "../headers/Player.h"
#include "../headers/Mage.h"
#include "../constants.h"

TEST(Mage , DefaultConstructor) 
{
	Mage m;
    EXPECT_EQ(m.stats[HEALTH], 30);
    EXPECT_EQ(m.stats[ATTACK_STRENGTH], 10);
    EXPECT_EQ(m.stats[INTELLIGENCE], 30);
    EXPECT_EQ(m.stats[LUCK], 1);
    EXPECT_EQ(m.stats[AGILITY], 1);
}

TEST(Mage , ChangeVals) 
{
	Mage m;
    m.setHealth(50);
    m.setAttackStrength(50);
    m.setIntelligence(50);
    m.setLuck(50);
    m.setAgility(50);
    EXPECT_EQ(m.stats[HEALTH], 50);
    EXPECT_EQ(m.stats[ATTACK_STRENGTH], 50);
    EXPECT_EQ(m.stats[INTELLIGENCE], 50);
    EXPECT_EQ(m.stats[LUCK], 50);
    EXPECT_EQ(m.stats[AGILITY], 50);
}

TEST(Mage , ArmorHealth) 
{
	Mage m;
    EXPECT_EQ(m.getArmorHealth(), 5);
}


#endif//__MAGE_TEST_HPP__
