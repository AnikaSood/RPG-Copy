#ifndef __WARRIOR_TEST_HPP__
#define __WARRIOR_TEST_HPP__

#include "gtest/gtest.h"
#include "../headers/Player.h"
#include "../headers/Warrior.h"
#include "../constants.h"

TEST(Warrior , DefaultConstructor) 
{
	Warrior w;
    EXPECT_EQ(w.stats[HEALTH], 50);
    EXPECT_EQ(w.stats[ATTACK_STRENGTH], 30);
    EXPECT_EQ(w.stats[INTELLIGENCE], 10);
    EXPECT_EQ(w.stats[LUCK], 1);
    EXPECT_EQ(w.stats[AGILITY], 0);
}

TEST(Warrior , ChangeVals) 
{
	Warrior w;
    w.setHealth(50);
    w.setAttackStrength(50);
    w.setIntelligence(50);
    w.setLuck(50);
    w.setAgility(50);
    EXPECT_EQ(w.stats[HEALTH], 50);
    EXPECT_EQ(w.stats[ATTACK_STRENGTH], 50);
    EXPECT_EQ(w.stats[INTELLIGENCE], 50);
    EXPECT_EQ(w.stats[LUCK], 50);
    EXPECT_EQ(w.stats[AGILITY], 50);
}

TEST(Warrior , ArmorHealth) 
{
	Warrior w;
    EXPECT_EQ(w.getArmorHealth(), 5);
}

#endif//__WARRIOR_TEST_HPP__
