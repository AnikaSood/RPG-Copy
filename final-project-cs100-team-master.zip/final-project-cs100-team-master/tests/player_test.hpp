#ifndef __PLAYER_TEST_HPP__
#define __PLAYER_TEST_HPP__

#include "gtest/gtest.h"
#include "../headers/Player.h"
#include "../constants.h"

TEST(Player , DefaultConstructor) 
{
	Player p;
    EXPECT_EQ(p.stats[HEALTH], 50);
    EXPECT_EQ(p.stats[ATTACK_STRENGTH], 10);
    EXPECT_EQ(p.stats[INTELLIGENCE], 10);
    EXPECT_EQ(p.stats[LUCK], 1);
    EXPECT_EQ(p.stats[AGILITY], 1);
}

TEST(Player , ChangeVals) 
{
	Player p;
    p.setHealth(50);
    p.setAttackStrength(50);
    p.setIntelligence(50);
    p.setLuck(50);
    p.setAgility(50);
    EXPECT_EQ(p.stats[HEALTH], 50);
    EXPECT_EQ(p.stats[ATTACK_STRENGTH], 50);
    EXPECT_EQ(p.stats[INTELLIGENCE], 50);
    EXPECT_EQ(p.stats[LUCK], 50);
    EXPECT_EQ(p.stats[AGILITY], 50);
}

TEST(Player , ArmorHealth) 
{
	Player p;
    EXPECT_EQ(p.getArmorHealth(), 5);
}


#endif//__PLAYER_TEST_HPP__
