#include "gtest/gtest.h"

#include "../headers/Mage.h"
#include "../headers/Warrior.h"
#include "../headers/Healer.h"
#include "../headers/Assassin.h"
#include "../headers/Player.h"
#include "../headers/Item.h"
#include "../headers/Weapon.h"

#include "assassin_test.hpp"
#include "mage_test.hpp"
#include "healer_test.hpp"
#include "warrior_test.hpp"
#include "player_test.hpp"
#include "armor_test.hpp"
#include "weapon_test.hpp"


int main(int argc, char **argv) 
{
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
