#ifndef __ARMOR_TEST_HPP__
#define __ARMOR_TEST_HPP__

#include "gtest/gtest.h"
#include "../headers/Player.h"
#include "../headers/Armor.h"
#include "../constants.h"

TEST(Armor , DefaultConstructor) 
{
	Armor a;
    EXPECT_EQ(a.name, "");
    EXPECT_EQ(a.levelItem, 0);
}

TEST(Armor , ChangeVals) 
{
	Armor a;
    a.setHealth(10);
    EXPECT_EQ(a.health, 10);
    EXPECT_EQ(a.item_stat[HEALTH], 10);
}

TEST(Armor , ArmorHealth) 
{
	Armor a;
    a.setHealth(12);
    EXPECT_EQ(a.getHealth(), 12);
}

#endif//__ASSASSIN_TEST_HPP__
