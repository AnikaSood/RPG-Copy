#ifndef __WEAPON_TEST_HPP__
#define __WEAPON_TEST_HPP__

#include "gtest/gtest.h"
#include "../headers/Item.h"
#include "../headers/Weapon.h"
#include "../constants.h"

TEST(Weapon , DefaultConstructor) 
{
	Weapon w;
    EXPECT_EQ(w.getName(), "");
    EXPECT_EQ(w.getAttack(), 5);
}

TEST(Weapon , NameConstructor) 
{
	Weapon w("Sword");
    EXPECT_EQ(w.getName(), "Sword");
    EXPECT_EQ(w.getAttack(), 5);
}

TEST(Weapon , SetAttack) 
{
	Weapon w;
    EXPECT_EQ(w.getAttack(), 5);
    w.setAttack(50);
    EXPECT_EQ(w.getAttack(), 50);
}


#endif//__WEAPON_TEST_HPP__
