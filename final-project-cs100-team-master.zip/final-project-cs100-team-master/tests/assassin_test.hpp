#ifndef __ASSASSIN_TEST_HPP__
#define __ASSASSIN_TEST_HPP__

#include "gtest/gtest.h"
#include "../headers/Player.h"
#include "../headers/Assassin.h"
#include "../constants.h"

TEST(Assassin , DefaultConstructor) 
{
	Assassin a;
    EXPECT_EQ(a.stats[HEALTH], 30);
    EXPECT_EQ(a.stats[ATTACK_STRENGTH], 10);
    EXPECT_EQ(a.stats[INTELLIGENCE], 10);
    EXPECT_EQ(a.stats[LUCK], 1);
    EXPECT_EQ(a.stats[AGILITY], 3);
}

TEST(Assassin , ChangeVals) 
{
	Assassin a;
    a.setHealth(50);
    a.setAttackStrength(50);
    a.setIntelligence(50);
    a.setLuck(50);
    a.setAgility(50);
    EXPECT_EQ(a.stats[HEALTH], 50);
    EXPECT_EQ(a.stats[ATTACK_STRENGTH], 50);
    EXPECT_EQ(a.stats[INTELLIGENCE], 50);
    EXPECT_EQ(a.stats[LUCK], 50);
    EXPECT_EQ(a.stats[AGILITY], 50);
}

TEST(Assassin , ArmorHealth) 
{
	Assassin a;
    EXPECT_EQ(a.getArmorHealth(), 5);
}

#endif//__ASSASSIN_TEST_HPP__
