#ifndef __HEALER_TEST_HPP__
#define __HEALER_TEST_HPP__

#include "gtest/gtest.h"
#include "../headers/Player.h"
#include "../headers/Healer.h"
#include "../constants.h"

TEST(Healer , DefaultConstructor) 
{
	Healer h;
    EXPECT_EQ(h.stats[HEALTH], 70);
    EXPECT_EQ(h.stats[ATTACK_STRENGTH], 5);
    EXPECT_EQ(h.stats[INTELLIGENCE], 10);
    EXPECT_EQ(h.stats[LUCK], 1);
    EXPECT_EQ(h.stats[AGILITY], 1);
}

TEST(Healer , ChangeVals)
{
	Healer h;
    h.setHealth(50);
    h.setAttackStrength(50);
    h.setIntelligence(50);
    h.setLuck(50);
    h.setAgility(50);
    EXPECT_EQ(h.stats[HEALTH], 50);
    EXPECT_EQ(h.stats[ATTACK_STRENGTH], 50);
    EXPECT_EQ(h.stats[INTELLIGENCE], 50);
    EXPECT_EQ(h.stats[LUCK], 50);
    EXPECT_EQ(h.stats[AGILITY], 50);
}

TEST(Healer , ArmorHealth) 
{
	Healer h;
    EXPECT_EQ(h.getArmorHealth(), 5);
}

#endif//__HEALER_TEST_HPP__
