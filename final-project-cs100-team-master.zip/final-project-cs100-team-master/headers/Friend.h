#ifndef FRIEND_H
#define FRIEND_H

#include "../headers/NPC.h"
#include <iostream>

/*
 * DERIVED NPC CLASS- FRIEND
*/
class Friend : public NPC
{
  public:
    Friend(string nm);
};

#endif //FRIEND_H