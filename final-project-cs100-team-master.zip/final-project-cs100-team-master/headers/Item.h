/*
 * Authors: Angelina Guzman, Krish Shah, Anika Sood, Kayla Tran
 * Created: 4/25/2022
 * Description: Header file for the Item class. The Item class will act as the
 * base class for three derived classes: Weapon, Potions, and Armor. The Item
 * class is not an abstract class, but there will be no instantiations of the
 * Item class in this program.
 * 
*/

#ifndef ITEM_H
#define ITEM_H

#include <iostream>
#include <string>
#include "../constants.h"

using namespace std;

class Item 
{
  public:
    /*
     * Protected data members
     *  name : a string that holds the name of the item
     *  item_stat[] : an array of integers that represent the amount to be
     * adjusted to the players stats (for example, +3 in the item_stats at index 0
     * will add 3 health to the player's stats) item : an integer that holds the
     * level of the Item, items with higher levels will deliver greater attacks
     *
    */
    int item_stat[STAT_SIZE];
    int levelItem;

    /*
     * Protected function
     *  adjustStats: iterates through item_stat[] and stats[] and modifies the
     *  item_stats[] displayStats: takes in the levelItem and returns the stats of
     * the item so the player can see it when they click on it in the inventory
     *                   
    */
    void adjustStats(int stat[STAT_SIZE]);
    void displayStats();

    Item();
    string name;
};

#endif
