#ifndef HEALER_H
#define HEALER_H

#include "../headers/Player.h"

class Healer : public Player
{
  public :
    Healer();//default constructor
    //~Healer();

  protected:
    // virtual void specialPower();
    // virtual void levelUp(int level);
};

#endif
