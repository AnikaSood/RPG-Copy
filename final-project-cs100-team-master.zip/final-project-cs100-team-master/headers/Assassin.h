#ifndef ASSASSIN_H
#define ASSASSIN_H

#include "../headers/Player.h"

class Assassin : public Player
{
  public:
    Assassin();//default constructor
    //~Assassin();
    // virtual void specialPower();
    // virtual void levelUp(int level);
};

#endif