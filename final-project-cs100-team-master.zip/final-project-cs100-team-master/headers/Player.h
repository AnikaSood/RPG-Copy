/*
 * Authors: Angelina Guzman, Krish Shah, Anika Sood, Kayla Tran
 * Created: 4/25/2022
 * Description: Header file for the Player class. The Player class will act as the
 * base class for the Warrior, Mage, Healer, and Assassin classes. Every Player
 * will have 6 main stats, a name, and a special power. As well as equipping items
 * (weapons, armor). The Player class is an abstract class.
*/

#ifndef PLAYER_H
#define PLAYER_H

#include <string>
#include "../headers/Item.h"
#include "../headers/Armor.h"
#include "../headers/Weapon.h"
#include "../headers/Potion.h"
#include "../constants.h"

using namespace std;

/*
* Constants
*  STATS_SIZE = the number of stats a player has
*  INVENTORY_SIZE = the number of items a player can have in their inventory
*/

/*
 * The indices of the stats in the stats[] and equip_inventory[] arrays. This will make it easier to
 * locate the specific stat categories throughout the program, to avoid using hard-coded values.
*/

class Player 
{
  public:
    Armor armor;
    Weapon weapon;
    Potion potion1;
    Potion potion2;
    Potion potion3;
    int stats[STAT_SIZE];
    Item inventory[INVENTORY_SIZE] = {armor, weapon, potion1, potion2, potion3};

    void setName(string);
    void setHealth(int);
    void setIntelligence(int);
    void setAgility(int);
    void setStamina(int);
    void setAttackStrength(int);
    void setLuck(int);

    int getArmorHealth();
    int getWeaponStrength();

    void playerLevelUp();

    string name;

    Player();
    //~Player();

};

#endif
