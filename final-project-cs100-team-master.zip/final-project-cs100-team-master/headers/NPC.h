/*
 * Authors: Angelina Guzman, Krish Shah, Anika Sood, Kayla Tran
 * Created: 5/4/2022
 * Description: Header file for the NPC class. 
 *
 * DESCRIPTION OF HEADER FILE HERE!!!!!!!!!!!
*/

#ifndef NPC_H
#define NPC_H

#include <iostream>
#include <string>
#include "../headers/Item.h"
#include "../constants.h"

using namespace std;

class NPC
{
  protected:
    string name;
    // Item inventory[INVENTORY_SIZE];
};

#endif
