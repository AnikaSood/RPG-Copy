#ifndef ENEMY_H
#define ENEMY_H

#include "../headers/NPC.h"
#include <iostream>

/*
 * DERIVED NPC CLASS- ENEMY
*/
class Enemy : public NPC
{
  private:
    int health, attack;
    string name;
    int inv[1];
  public:
    Enemy(string nm); 
    void setStats(int, int);
    int getAttack();
    int getHealth();
    void adjustHealth(int);
};

#endif //ENEMY_H