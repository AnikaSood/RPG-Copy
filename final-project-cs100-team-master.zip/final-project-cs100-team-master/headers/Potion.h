#ifndef POTION_H
#define POTION_H

#include "../headers/Item.h"

class Potion : public Item
{
  public :
    //default constructor
    Potion();
    int health;
    int luck;
    int agility;
    int getHealth();
    int getLuck();
    int getAgility();

    void setHealth(int);
    void setLuck(int);
    void setAgility(int);
};

#endif //POTION_H