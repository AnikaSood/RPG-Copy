#ifndef MAGE_H
#define MAGE_H

#include "../headers/Player.h"

class Mage : public Player
{
  public :
   Mage();//default constructor
    //~Mage();
    //protected:
    // virtual void specialPower();
    // virtual void levelUp(int level);
};

#endif // MAGE_H