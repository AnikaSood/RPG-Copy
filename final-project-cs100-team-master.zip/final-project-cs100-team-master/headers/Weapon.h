#ifndef WEAPON_H
#define WEAPON_H

#include "../headers/Item.h"

class Weapon : public Item 
{
  public:
    Weapon();
    Weapon(string);

    int attack;

    void setAttack(int);
    int getAttack();

    string getName();
};

#endif //WEAPON_H
