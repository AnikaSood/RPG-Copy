#ifndef ARMOR_H
#define ARMOR_H

#include "../headers/Item.h"

class Armor : public Item 
{
  public:
    Armor();
    Armor(string);
    int health;
    void setHealth(int);
    int getHealth();
};


#endif //ARMOR_H