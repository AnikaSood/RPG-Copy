#ifndef WARRIOR_H
#define WARRIOR_H

#include "../headers/Player.h"

class Warrior : public Player
{
  public :
    Warrior();// default constructor
    //~Warrior();
    //protected:
    //  virtual void specialPower();
    //  virtual void levelUp(int level);
};

#endif // WARRIOR_H